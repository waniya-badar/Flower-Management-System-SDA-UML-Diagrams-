const login = () => {
    const email = document.getElementById('adminEmail').value;
    const adminID = document.getElementById('adminID').value;

    // Create an XMLHttpRequest object
    const xhr = new XMLHttpRequest();

    // Open a POST request
    xhr.open("POST", "http://localhost/BDPROJECTWEBSITE/inventory.php", true);

    // Set the request header to indicate JSON content
    xhr.setRequestHeader("Content-Type", "application/json");

    // Handle the response
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                try {
                    // Parse the JSON response
                    const response = JSON.parse(xhr.responseText);
                    console.log("Response received:", response);

                    if (response.success) {
                        alert("Login successful!");
                    } else {
                        alert("Login failed: " + response.message);
                    }
                } catch (error) {
                    console.error("Failed to parse JSON response:", error);
                }
            } else {
                console.error("Request failed with status:", xhr.status, xhr.statusText);
            }
        }
    };

    // Create the request body
    const requestBody = JSON.stringify({
        action: "adminLogin",
        email: email,
        adminID: adminID
    });

    // Send the request
    xhr.send(requestBody);
};
